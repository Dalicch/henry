'use strict';

var express = require('express');
var router = express.Router();
module.exports = router;
var model = require('../models/model');


// escriban sus rutas acá
// siéntanse libres de dividir entre archivos si lo necesitan


server.get('/families', (req,res)=> 
   
{   res.body([]) });