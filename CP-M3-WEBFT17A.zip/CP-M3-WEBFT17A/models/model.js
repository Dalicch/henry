'use strict';

var characters = [];

var families = [];


module.exports = {
  reset: function () {
    // No es necesario modificar esta función (Ya está completa)
    characters = [];
    families = [];
  },
  // ==== COMPLETEN LAS SIGUIENTES FUNCIONES (vean los test de `model.js`) =====
  listCharacter: function (family, pluckName) {
    // Devuelve un arreglo con todos los personajes
    // Si recibe un nombre de familia como parámetro debería filtrar solo los personajes de ella
    // Si recibe un segundo parámetro en true debe devolver únicamente los nombres de los personajes
    if (!family && !pluckName) return characters
    
    if (!pluckName) {var fam = families.filter(e => e.family === family)
      return characters.filter(e => e.familyId === fam[0].familyId)
    }else {var fam = families.filter(e => e.family === family)
           var char =  characters.filter(e => e.familyId === fam[0].familyId)
           return char.map(e => e.name)
          
    }
  
  },
  addFamily: function (name) {
  
    // Agrega el apellido de una nueva familia verificando que no exista
    // Debe retornar el nombre de la familia agregado o existente
  for (var i of families){
    if (i.family === name) return name
  }
  families.push({'family': name, 'familyId': families.length +1})
  },

  listFamilies: function() {
    // Devuelve un arreglo con todas las familias
    return families
  },

  addCharacter: function(name, age, family) {
    // Agrega un nuevo personaje, inicialmente sus frases (quotes) deben estar "vacias"
    // Adicionalmente va a ser necesario guardar el número de familia y no su nombre
    // El número de familia debe empezar desde 1 y no desde 0.
    // Debe retornar el personaje creado
    var id = 0
    for (var i of families) {
      if (i.family === family){id = i.familyId, characters.push({"name": name, "age": age,"quotes": [], "familyId": id})}
    }
  },
  addQuote: function(name, quote) {
    // Agrega una nueva frase a un personaje en particular con el formato:
    // {text: "Este es el texto de la frase", season: 3}
    var {text, season} = quote
    for( var i of characters){
       if (i.name === name) {
         if(text) {
           i.quotes.push({text: text, season:season})
         }
       }
    }
  
},
  showQuotes: function(name) {
    // Devuelve todas las frases de un personaje en particular
    for (var i of characters){
      if (i.name === name){
        return i.quotes
      }
     return []
    }
  },
};
